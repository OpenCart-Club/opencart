<?php
// Heading
$_['heading_title'] = 'Dashboard';

// Error
$_['error_install'] = 'Warning: Install folder still exists and should be deleted for security reasons!';
$_['security_warning'] = '<b>Important security recommendation!</b> Move the storage folder outside the main site folder. <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-security">Move...</button>';
